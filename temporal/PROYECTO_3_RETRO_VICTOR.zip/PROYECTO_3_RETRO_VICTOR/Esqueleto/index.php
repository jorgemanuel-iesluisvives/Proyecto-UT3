<?php
session_start();

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION["posts"])) {
    $_SESSION["posts"] = [];
}

// BORRAR POST
if (isset($_POST["delete_id"])) {
    foreach ($_SESSION["posts"] as $key => $post) {
        if ($post["id"] == $_POST["delete_id"]) {
            unset($_SESSION["posts"][$key]);
        }
    }
    $_SESSION["posts"] = array_values($_SESSION["posts"]);
    header("Location: index.php");
    exit;
}

$posts = $_SESSION["posts"];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>RetroGames - Feed</title>
    <link rel="stylesheet" href="recursos/style.css">
</head>
<body>

    <div class="header">
        <div class="header-title">RetroGames</div>
        <div class="header-user">
            👤 <?= htmlspecialchars($_SESSION["user"]) ?> |
            <a href="logout.php">Cerrar sesión</a>
        </div>
    </div>

    <a href="add_post.php">Añadir tu juego retro favorito</a>

    <?php if (empty($posts)): ?>
        <p>No hay publicaciones todavía.</p>
    <?php endif; ?>

    <?php foreach ($posts as $post): ?>
        <div class="post">
            <h3><?= htmlspecialchars($post["title"]) ?></h3>

            <img src="<?= htmlspecialchars($post["image"]) ?>">

            <p><?= htmlspecialchars(substr($post["description"], 0, 255)) ?></p>

            <strong>❤️ <?= $post["likes"] ?> likes</strong>

            <form method="post">
                <input type="hidden" name="delete_id" value="<?= $post["id"] ?>">
                <button type="submit">Borrar post</button>
            </form>
        </div>
    <?php endforeach; ?>

</body>