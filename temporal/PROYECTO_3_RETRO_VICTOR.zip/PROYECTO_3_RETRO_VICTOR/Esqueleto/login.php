<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $_SESSION["user"] = $_POST["username"] ?: "Invitado";
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - RetroGames</title>
    <link rel="stylesheet" href="recursos/style.css">
</head>
<body>

<div class="header">
    <div class="header-title">RetroGames</div>
</div>

<h2>Iniciar sesión</h2>

<form method="post">
    <label>Usuario</label><br>
    <input type="text" name="username" required><br><br>

    <label>Contraseña</label><br>
    <input type="password" name="password"><br><br>

    <button type="submit">Entrar</button>
</form>

</body>
</html>
