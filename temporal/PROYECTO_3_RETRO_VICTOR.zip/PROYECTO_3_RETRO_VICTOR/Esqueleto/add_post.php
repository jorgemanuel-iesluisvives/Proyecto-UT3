<?php
session_start();

// Inicializar posts
if (!isset($_SESSION["posts"])) {
    $_SESSION["posts"] = [];
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $uploadDir = "recursos/uploads/";
    $imageName = time() . "_" . basename($_FILES["image"]["name"]);
    $uploadPath = $uploadDir . $imageName;

    move_uploaded_file($_FILES["image"]["tmp_name"], $uploadPath);

    $newPost = [
        "id" => time(),
        "title" => $_POST["title"] ?? "",
        "description" => $_POST["description"] ?? "",
        "image" => $uploadPath,
        "likes" => 0,
        "comments" => []
    ];

    $_SESSION["posts"][] = $newPost;

    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Añadir Juego Retro</title>
    <link rel="stylesheet" href="recursos/style.css">
</head>
<body>

    <div class="header">
        <div class="header-title">RetroGames</div>
    </div>

    <h2>Añadir juego retro</h2>

    <form method="post" enctype="multipart/form-data">
        <label>Nombre del juego</label><br>
        <input type="text" name="title" required><br><br>

        <label>Descripción (máx 255)</label><br>
        <textarea name="description" maxlength="255" required></textarea><br><br>

        <label>Imagen</label><br>
        <input type="file" name="image" required><br><br>

        <button type="submit">Subir</button>
        <a href="index.php" class="btn-cancelar">Volver</a>
    </form>
</body>